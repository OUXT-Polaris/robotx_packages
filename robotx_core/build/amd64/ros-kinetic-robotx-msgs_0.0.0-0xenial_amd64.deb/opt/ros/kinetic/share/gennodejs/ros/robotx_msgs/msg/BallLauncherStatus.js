// Auto-generated. Do not edit!

// (in-package robotx_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class BallLauncherStatus {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.ball_remains = null;
      this.ball_launched = null;
    }
    else {
      if (initObj.hasOwnProperty('ball_remains')) {
        this.ball_remains = initObj.ball_remains
      }
      else {
        this.ball_remains = 0;
      }
      if (initObj.hasOwnProperty('ball_launched')) {
        this.ball_launched = initObj.ball_launched
      }
      else {
        this.ball_launched = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type BallLauncherStatus
    // Serialize message field [ball_remains]
    bufferOffset = _serializer.int8(obj.ball_remains, buffer, bufferOffset);
    // Serialize message field [ball_launched]
    bufferOffset = _serializer.int8(obj.ball_launched, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type BallLauncherStatus
    let len;
    let data = new BallLauncherStatus(null);
    // Deserialize message field [ball_remains]
    data.ball_remains = _deserializer.int8(buffer, bufferOffset);
    // Deserialize message field [ball_launched]
    data.ball_launched = _deserializer.int8(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 2;
  }

  static datatype() {
    // Returns string type for a message object
    return 'robotx_msgs/BallLauncherStatus';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'ac1686e5cbfc217b71e799684162a01b';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    int8 ball_remains
    int8 ball_launched
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new BallLauncherStatus(null);
    if (msg.ball_remains !== undefined) {
      resolved.ball_remains = msg.ball_remains;
    }
    else {
      resolved.ball_remains = 0
    }

    if (msg.ball_launched !== undefined) {
      resolved.ball_launched = msg.ball_launched;
    }
    else {
      resolved.ball_launched = 0
    }

    return resolved;
    }
};

module.exports = BallLauncherStatus;
