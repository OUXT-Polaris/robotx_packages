// Auto-generated. Do not edit!

// (in-package robotx_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let ObjectType = require('./ObjectType.js');
let sensor_msgs = _finder('sensor_msgs');
let std_msgs = _finder('std_msgs');
let jsk_recognition_msgs = _finder('jsk_recognition_msgs');

//-----------------------------------------------------------

class ObjectRegionOfInterest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.roi_2d = null;
      this.roi_3d = null;
      this.object_type = null;
      this.objectness = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('roi_2d')) {
        this.roi_2d = initObj.roi_2d
      }
      else {
        this.roi_2d = new sensor_msgs.msg.RegionOfInterest();
      }
      if (initObj.hasOwnProperty('roi_3d')) {
        this.roi_3d = initObj.roi_3d
      }
      else {
        this.roi_3d = new jsk_recognition_msgs.msg.BoundingBox();
      }
      if (initObj.hasOwnProperty('object_type')) {
        this.object_type = initObj.object_type
      }
      else {
        this.object_type = new ObjectType();
      }
      if (initObj.hasOwnProperty('objectness')) {
        this.objectness = initObj.objectness
      }
      else {
        this.objectness = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type ObjectRegionOfInterest
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [roi_2d]
    bufferOffset = sensor_msgs.msg.RegionOfInterest.serialize(obj.roi_2d, buffer, bufferOffset);
    // Serialize message field [roi_3d]
    bufferOffset = jsk_recognition_msgs.msg.BoundingBox.serialize(obj.roi_3d, buffer, bufferOffset);
    // Serialize message field [object_type]
    bufferOffset = ObjectType.serialize(obj.object_type, buffer, bufferOffset);
    // Serialize message field [objectness]
    bufferOffset = _serializer.float32(obj.objectness, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type ObjectRegionOfInterest
    let len;
    let data = new ObjectRegionOfInterest(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [roi_2d]
    data.roi_2d = sensor_msgs.msg.RegionOfInterest.deserialize(buffer, bufferOffset);
    // Deserialize message field [roi_3d]
    data.roi_3d = jsk_recognition_msgs.msg.BoundingBox.deserialize(buffer, bufferOffset);
    // Deserialize message field [object_type]
    data.object_type = ObjectType.deserialize(buffer, bufferOffset);
    // Deserialize message field [objectness]
    data.objectness = _deserializer.float32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    length += jsk_recognition_msgs.msg.BoundingBox.getMessageSize(object.roi_3d);
    return length + 22;
  }

  static datatype() {
    // Returns string type for a message object
    return 'robotx_msgs/ObjectRegionOfInterest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '41beb0daeea314f6f1161a68f26fd6f8';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    Header header
    sensor_msgs/RegionOfInterest roi_2d
    jsk_recognition_msgs/BoundingBox roi_3d
    robotx_msgs/ObjectType object_type
    float32 objectness
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    # 0: no frame
    # 1: global frame
    string frame_id
    
    ================================================================================
    MSG: sensor_msgs/RegionOfInterest
    # This message is used to specify a region of interest within an image.
    #
    # When used to specify the ROI setting of the camera when the image was
    # taken, the height and width fields should either match the height and
    # width fields for the associated image; or height = width = 0
    # indicates that the full resolution image was captured.
    
    uint32 x_offset  # Leftmost pixel of the ROI
                     # (0 if the ROI includes the left edge of the image)
    uint32 y_offset  # Topmost pixel of the ROI
                     # (0 if the ROI includes the top edge of the image)
    uint32 height    # Height of ROI
    uint32 width     # Width of ROI
    
    # True if a distinct rectified ROI should be calculated from the "raw"
    # ROI in this message. Typically this should be False if the full image
    # is captured (ROI not used), and True if a subwindow is captured (ROI
    # used).
    bool do_rectify
    
    ================================================================================
    MSG: jsk_recognition_msgs/BoundingBox
    # BoundingBox represents a oriented bounding box.
    Header header
    geometry_msgs/Pose pose
    geometry_msgs/Vector3 dimensions  # size of bounding box (x, y, z)
    # You can use this field to hold value such as likelihood
    float32 value
    uint32 label
    
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    ================================================================================
    MSG: geometry_msgs/Vector3
    # This represents a vector in free space. 
    # It is only meant to represent a direction. Therefore, it does not
    # make sense to apply a translation to it (e.g., when applying a 
    # generic rigid transformation to a Vector3, tf2 will only apply the
    # rotation). If you want your data to be translatable too, use the
    # geometry_msgs/Point message instead.
    
    float64 x
    float64 y
    float64 z
    ================================================================================
    MSG: robotx_msgs/ObjectType
    uint8 ID
    uint8 OTHER = 0
    uint8 GREEN_BUOY = 1
    uint8 RED_BUOY = 2
    uint8 WHITE_BUOY = 3
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new ObjectRegionOfInterest(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.roi_2d !== undefined) {
      resolved.roi_2d = sensor_msgs.msg.RegionOfInterest.Resolve(msg.roi_2d)
    }
    else {
      resolved.roi_2d = new sensor_msgs.msg.RegionOfInterest()
    }

    if (msg.roi_3d !== undefined) {
      resolved.roi_3d = jsk_recognition_msgs.msg.BoundingBox.Resolve(msg.roi_3d)
    }
    else {
      resolved.roi_3d = new jsk_recognition_msgs.msg.BoundingBox()
    }

    if (msg.object_type !== undefined) {
      resolved.object_type = ObjectType.Resolve(msg.object_type)
    }
    else {
      resolved.object_type = new ObjectType()
    }

    if (msg.objectness !== undefined) {
      resolved.objectness = msg.objectness;
    }
    else {
      resolved.objectness = 0.0
    }

    return resolved;
    }
};

module.exports = ObjectRegionOfInterest;
