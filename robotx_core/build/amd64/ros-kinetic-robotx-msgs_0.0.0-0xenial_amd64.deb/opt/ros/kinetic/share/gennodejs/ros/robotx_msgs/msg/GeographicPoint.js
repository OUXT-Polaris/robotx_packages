// Auto-generated. Do not edit!

// (in-package robotx_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let geographic_msgs = _finder('geographic_msgs');

//-----------------------------------------------------------

class GeographicPoint {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.geographic_point = null;
      this.node_id = null;
    }
    else {
      if (initObj.hasOwnProperty('geographic_point')) {
        this.geographic_point = initObj.geographic_point
      }
      else {
        this.geographic_point = new geographic_msgs.msg.GeoPoint();
      }
      if (initObj.hasOwnProperty('node_id')) {
        this.node_id = initObj.node_id
      }
      else {
        this.node_id = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type GeographicPoint
    // Serialize message field [geographic_point]
    bufferOffset = geographic_msgs.msg.GeoPoint.serialize(obj.geographic_point, buffer, bufferOffset);
    // Serialize message field [node_id]
    bufferOffset = _serializer.uint64(obj.node_id, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type GeographicPoint
    let len;
    let data = new GeographicPoint(null);
    // Deserialize message field [geographic_point]
    data.geographic_point = geographic_msgs.msg.GeoPoint.deserialize(buffer, bufferOffset);
    // Deserialize message field [node_id]
    data.node_id = _deserializer.uint64(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 32;
  }

  static datatype() {
    // Returns string type for a message object
    return 'robotx_msgs/GeographicPoint';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '0b9d9df8d4ccad88d85f8d1fdbf926fe';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    geographic_msgs/GeoPoint geographic_point
    uint64 node_id
    ================================================================================
    MSG: geographic_msgs/GeoPoint
    # Geographic point, using the WGS 84 reference ellipsoid.
    
    # Latitude [degrees]. Positive is north of equator; negative is south
    # (-90 <= latitude <= +90).
    float64 latitude
    
    # Longitude [degrees]. Positive is east of prime meridian; negative is
    # west (-180 <= longitude <= +180). At the poles, latitude is -90 or
    # +90, and longitude is irrelevant, but must be in range.
    float64 longitude
    
    # Altitude [m]. Positive is above the WGS 84 ellipsoid (NaN if unspecified).
    float64 altitude
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new GeographicPoint(null);
    if (msg.geographic_point !== undefined) {
      resolved.geographic_point = geographic_msgs.msg.GeoPoint.Resolve(msg.geographic_point)
    }
    else {
      resolved.geographic_point = new geographic_msgs.msg.GeoPoint()
    }

    if (msg.node_id !== undefined) {
      resolved.node_id = msg.node_id;
    }
    else {
      resolved.node_id = 0
    }

    return resolved;
    }
};

module.exports = GeographicPoint;
