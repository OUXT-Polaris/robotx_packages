// Auto-generated. Do not edit!

// (in-package robotx_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class GeographicLine {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.start_node_id = null;
      this.end_node_id = null;
      this.id = null;
    }
    else {
      if (initObj.hasOwnProperty('start_node_id')) {
        this.start_node_id = initObj.start_node_id
      }
      else {
        this.start_node_id = 0;
      }
      if (initObj.hasOwnProperty('end_node_id')) {
        this.end_node_id = initObj.end_node_id
      }
      else {
        this.end_node_id = 0;
      }
      if (initObj.hasOwnProperty('id')) {
        this.id = initObj.id
      }
      else {
        this.id = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type GeographicLine
    // Serialize message field [start_node_id]
    bufferOffset = _serializer.uint64(obj.start_node_id, buffer, bufferOffset);
    // Serialize message field [end_node_id]
    bufferOffset = _serializer.uint64(obj.end_node_id, buffer, bufferOffset);
    // Serialize message field [id]
    bufferOffset = _serializer.uint64(obj.id, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type GeographicLine
    let len;
    let data = new GeographicLine(null);
    // Deserialize message field [start_node_id]
    data.start_node_id = _deserializer.uint64(buffer, bufferOffset);
    // Deserialize message field [end_node_id]
    data.end_node_id = _deserializer.uint64(buffer, bufferOffset);
    // Deserialize message field [id]
    data.id = _deserializer.uint64(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 24;
  }

  static datatype() {
    // Returns string type for a message object
    return 'robotx_msgs/GeographicLine';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '9456174463f839726d2bcf9ba81e6f72';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    uint64 start_node_id
    uint64 end_node_id
    uint64 id 
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new GeographicLine(null);
    if (msg.start_node_id !== undefined) {
      resolved.start_node_id = msg.start_node_id;
    }
    else {
      resolved.start_node_id = 0
    }

    if (msg.end_node_id !== undefined) {
      resolved.end_node_id = msg.end_node_id;
    }
    else {
      resolved.end_node_id = 0
    }

    if (msg.id !== undefined) {
      resolved.id = msg.id;
    }
    else {
      resolved.id = 0
    }

    return resolved;
    }
};

module.exports = GeographicLine;
