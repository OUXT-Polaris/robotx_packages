// Auto-generated. Do not edit!

// (in-package robotx_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let RegionOfInterest2D = require('./RegionOfInterest2D.js');

//-----------------------------------------------------------

class RegionOfInterest2DArray {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.object_rois = null;
    }
    else {
      if (initObj.hasOwnProperty('object_rois')) {
        this.object_rois = initObj.object_rois
      }
      else {
        this.object_rois = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type RegionOfInterest2DArray
    // Serialize message field [object_rois]
    // Serialize the length for message field [object_rois]
    bufferOffset = _serializer.uint32(obj.object_rois.length, buffer, bufferOffset);
    obj.object_rois.forEach((val) => {
      bufferOffset = RegionOfInterest2D.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type RegionOfInterest2DArray
    let len;
    let data = new RegionOfInterest2DArray(null);
    // Deserialize message field [object_rois]
    // Deserialize array length for message field [object_rois]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.object_rois = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.object_rois[i] = RegionOfInterest2D.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    object.object_rois.forEach((val) => {
      length += RegionOfInterest2D.getMessageSize(val);
    });
    return length + 4;
  }

  static datatype() {
    // Returns string type for a message object
    return 'robotx_msgs/RegionOfInterest2DArray';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'c0c603f138957dba0f00c0bbbfb26d25';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    robotx_msgs/RegionOfInterest2D[] object_rois
    ================================================================================
    MSG: robotx_msgs/RegionOfInterest2D
    sensor_msgs/RegionOfInterest roi
    string label
    float32 objectness
    ================================================================================
    MSG: sensor_msgs/RegionOfInterest
    # This message is used to specify a region of interest within an image.
    #
    # When used to specify the ROI setting of the camera when the image was
    # taken, the height and width fields should either match the height and
    # width fields for the associated image; or height = width = 0
    # indicates that the full resolution image was captured.
    
    uint32 x_offset  # Leftmost pixel of the ROI
                     # (0 if the ROI includes the left edge of the image)
    uint32 y_offset  # Topmost pixel of the ROI
                     # (0 if the ROI includes the top edge of the image)
    uint32 height    # Height of ROI
    uint32 width     # Width of ROI
    
    # True if a distinct rectified ROI should be calculated from the "raw"
    # ROI in this message. Typically this should be False if the full image
    # is captured (ROI not used), and True if a subwindow is captured (ROI
    # used).
    bool do_rectify
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new RegionOfInterest2DArray(null);
    if (msg.object_rois !== undefined) {
      resolved.object_rois = new Array(msg.object_rois.length);
      for (let i = 0; i < resolved.object_rois.length; ++i) {
        resolved.object_rois[i] = RegionOfInterest2D.Resolve(msg.object_rois[i]);
      }
    }
    else {
      resolved.object_rois = []
    }

    return resolved;
    }
};

module.exports = RegionOfInterest2DArray;
