// Auto-generated. Do not edit!

// (in-package robotx_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class Heartbeat {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.utc_time_hh = null;
      this.utc_time_mm = null;
      this.utc_time_ss = null;
      this.latitude = null;
      this.north_or_south = null;
      this.longitude = null;
      this.east_or_west = null;
      this.team_id = null;
      this.vehicle_mode = null;
      this.current_task_number = null;
    }
    else {
      if (initObj.hasOwnProperty('utc_time_hh')) {
        this.utc_time_hh = initObj.utc_time_hh
      }
      else {
        this.utc_time_hh = '';
      }
      if (initObj.hasOwnProperty('utc_time_mm')) {
        this.utc_time_mm = initObj.utc_time_mm
      }
      else {
        this.utc_time_mm = '';
      }
      if (initObj.hasOwnProperty('utc_time_ss')) {
        this.utc_time_ss = initObj.utc_time_ss
      }
      else {
        this.utc_time_ss = '';
      }
      if (initObj.hasOwnProperty('latitude')) {
        this.latitude = initObj.latitude
      }
      else {
        this.latitude = 0.0;
      }
      if (initObj.hasOwnProperty('north_or_south')) {
        this.north_or_south = initObj.north_or_south
      }
      else {
        this.north_or_south = false;
      }
      if (initObj.hasOwnProperty('longitude')) {
        this.longitude = initObj.longitude
      }
      else {
        this.longitude = 0.0;
      }
      if (initObj.hasOwnProperty('east_or_west')) {
        this.east_or_west = initObj.east_or_west
      }
      else {
        this.east_or_west = false;
      }
      if (initObj.hasOwnProperty('team_id')) {
        this.team_id = initObj.team_id
      }
      else {
        this.team_id = '';
      }
      if (initObj.hasOwnProperty('vehicle_mode')) {
        this.vehicle_mode = initObj.vehicle_mode
      }
      else {
        this.vehicle_mode = 0;
      }
      if (initObj.hasOwnProperty('current_task_number')) {
        this.current_task_number = initObj.current_task_number
      }
      else {
        this.current_task_number = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type Heartbeat
    // Serialize message field [utc_time_hh]
    bufferOffset = _serializer.string(obj.utc_time_hh, buffer, bufferOffset);
    // Serialize message field [utc_time_mm]
    bufferOffset = _serializer.string(obj.utc_time_mm, buffer, bufferOffset);
    // Serialize message field [utc_time_ss]
    bufferOffset = _serializer.string(obj.utc_time_ss, buffer, bufferOffset);
    // Serialize message field [latitude]
    bufferOffset = _serializer.float32(obj.latitude, buffer, bufferOffset);
    // Serialize message field [north_or_south]
    bufferOffset = _serializer.bool(obj.north_or_south, buffer, bufferOffset);
    // Serialize message field [longitude]
    bufferOffset = _serializer.float32(obj.longitude, buffer, bufferOffset);
    // Serialize message field [east_or_west]
    bufferOffset = _serializer.bool(obj.east_or_west, buffer, bufferOffset);
    // Serialize message field [team_id]
    bufferOffset = _serializer.string(obj.team_id, buffer, bufferOffset);
    // Serialize message field [vehicle_mode]
    bufferOffset = _serializer.uint8(obj.vehicle_mode, buffer, bufferOffset);
    // Serialize message field [current_task_number]
    bufferOffset = _serializer.uint8(obj.current_task_number, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type Heartbeat
    let len;
    let data = new Heartbeat(null);
    // Deserialize message field [utc_time_hh]
    data.utc_time_hh = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [utc_time_mm]
    data.utc_time_mm = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [utc_time_ss]
    data.utc_time_ss = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [latitude]
    data.latitude = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [north_or_south]
    data.north_or_south = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [longitude]
    data.longitude = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [east_or_west]
    data.east_or_west = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [team_id]
    data.team_id = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [vehicle_mode]
    data.vehicle_mode = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [current_task_number]
    data.current_task_number = _deserializer.uint8(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.utc_time_hh.length;
    length += object.utc_time_mm.length;
    length += object.utc_time_ss.length;
    length += object.team_id.length;
    return length + 28;
  }

  static datatype() {
    // Returns string type for a message object
    return 'robotx_msgs/Heartbeat';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'b665406e9fc5f5a21b0e3ff374d31e66';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    #int32 utc_time #hhmmss
    string utc_time_hh
    string utc_time_mm
    string utc_time_ss
    float32 latitude
    
    bool north_or_south
    bool NORTH = 0
    bool SOUTH = 1
    
    float32 longitude
    
    bool east_or_west
    bool EAST = 0
    bool WEST = 1
    
    string team_id
    
    uint8 vehicle_mode
    uint8 REMOTE_OPERATED = 0
    uint8 AUTONOMOUS = 1
    uint8 EMERGENCY = 2
    
    uint8 current_task_number
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new Heartbeat(null);
    if (msg.utc_time_hh !== undefined) {
      resolved.utc_time_hh = msg.utc_time_hh;
    }
    else {
      resolved.utc_time_hh = ''
    }

    if (msg.utc_time_mm !== undefined) {
      resolved.utc_time_mm = msg.utc_time_mm;
    }
    else {
      resolved.utc_time_mm = ''
    }

    if (msg.utc_time_ss !== undefined) {
      resolved.utc_time_ss = msg.utc_time_ss;
    }
    else {
      resolved.utc_time_ss = ''
    }

    if (msg.latitude !== undefined) {
      resolved.latitude = msg.latitude;
    }
    else {
      resolved.latitude = 0.0
    }

    if (msg.north_or_south !== undefined) {
      resolved.north_or_south = msg.north_or_south;
    }
    else {
      resolved.north_or_south = false
    }

    if (msg.longitude !== undefined) {
      resolved.longitude = msg.longitude;
    }
    else {
      resolved.longitude = 0.0
    }

    if (msg.east_or_west !== undefined) {
      resolved.east_or_west = msg.east_or_west;
    }
    else {
      resolved.east_or_west = false
    }

    if (msg.team_id !== undefined) {
      resolved.team_id = msg.team_id;
    }
    else {
      resolved.team_id = ''
    }

    if (msg.vehicle_mode !== undefined) {
      resolved.vehicle_mode = msg.vehicle_mode;
    }
    else {
      resolved.vehicle_mode = 0
    }

    if (msg.current_task_number !== undefined) {
      resolved.current_task_number = msg.current_task_number;
    }
    else {
      resolved.current_task_number = 0
    }

    return resolved;
    }
};

// Constants for message
Heartbeat.Constants = {
  NORTH: false,
  SOUTH: true,
  EAST: false,
  WEST: true,
  REMOTE_OPERATED: 0,
  AUTONOMOUS: 1,
  EMERGENCY: 2,
}

module.exports = Heartbeat;
