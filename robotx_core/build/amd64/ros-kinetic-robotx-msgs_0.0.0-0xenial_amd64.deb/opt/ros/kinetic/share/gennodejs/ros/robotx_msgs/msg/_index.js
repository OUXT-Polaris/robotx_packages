
"use strict";

let RegionOfInterest2DArray = require('./RegionOfInterest2DArray.js');
let ObjectRegionOfInterestArray = require('./ObjectRegionOfInterestArray.js');
let ObjectRegionOfInterest = require('./ObjectRegionOfInterest.js');
let Heartbeat = require('./Heartbeat.js');
let GeographicPoint = require('./GeographicPoint.js');
let TechnicalDirectorNetworkStatus = require('./TechnicalDirectorNetworkStatus.js');
let ObjectType = require('./ObjectType.js');
let RegionOfInterest2D = require('./RegionOfInterest2D.js');
let UsvDrive = require('./UsvDrive.js');
let BallLauncherStatus = require('./BallLauncherStatus.js');
let GeographicMap = require('./GeographicMap.js');
let GeographicLine = require('./GeographicLine.js');

module.exports = {
  RegionOfInterest2DArray: RegionOfInterest2DArray,
  ObjectRegionOfInterestArray: ObjectRegionOfInterestArray,
  ObjectRegionOfInterest: ObjectRegionOfInterest,
  Heartbeat: Heartbeat,
  GeographicPoint: GeographicPoint,
  TechnicalDirectorNetworkStatus: TechnicalDirectorNetworkStatus,
  ObjectType: ObjectType,
  RegionOfInterest2D: RegionOfInterest2D,
  UsvDrive: UsvDrive,
  BallLauncherStatus: BallLauncherStatus,
  GeographicMap: GeographicMap,
  GeographicLine: GeographicLine,
};
